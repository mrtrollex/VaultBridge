"""Persistence repositories for VaultBridge."""
